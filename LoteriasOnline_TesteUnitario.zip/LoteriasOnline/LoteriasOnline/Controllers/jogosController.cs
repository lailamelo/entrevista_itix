﻿using System;
using System.Web;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

using LoteriasOnline.Models;
using LoteriasOnline.Services;
using Microsoft.Extensions.Caching.Memory;

namespace LoteriasOnline.Controllers
{
    /*
     * BadRequestResult (400)
     * NotFoundResult (404)
     * OkObjectResult (200)
     */

    [Route("api/[controller]")]
    [Produces("application/json")]
    //[ApiController] //original
    public class JogosController : Controller//ControllerBase
    {
        private JogoRepository jogosRepository;
        private IMemoryCache _cache;
        public JogosController(IMemoryCache memoryCache)
        {
            _cache = memoryCache;
            this.jogosRepository = new JogoRepository();
        }

        public List<Jogo> Get()
        {
            return this.jogosRepository.GetAllJogos();
        }

        // GET api/jogos/getJogos
        //[HttpGet] //original
        [HttpGet(Name = "getJogos")]
        [Route("getJogos")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        public IActionResult getJogos()
        {
            try
            {
                List<Jogo> cacheEntry = _cache.GetOrCreate(CacheKeys.Jogo, entry => { return Get(); });

                //Execute
                cacheEntry = cacheEntry.OrderBy(x => x.id).ToList();

                return Ok(cacheEntry);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // GET api/jogos/getJogo/5
        [HttpGet("{id}", Name = "getJogo")]
        [Route("getJogo/{id}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult getJogo(int id)
        {
            try
            {
                List<Jogo> cacheEntry = _cache.GetOrCreate(CacheKeys.Jogo, entry => { return (List<Jogo>)(((OkObjectResult)getJogos()).Value); });

                Jogo jogo = cacheEntry.Find(x => x.id.Equals(id));

                if (jogo == null)
                {
                    return NotFound();
                }

                return Ok(jogo);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // POST api/jogos/addJogo
        [HttpPost(Name = "addJogo")]
        [Route("addJogo")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        public IActionResult addJogo([FromBody] Jogo jogo)
        {
            try
            {
                List<Jogo> cacheEntry = _cache.GetOrCreate(CacheKeys.Jogo, entry => { return (List<Jogo>)(((OkObjectResult)getJogos()).Value); });

                jogo.id = cacheEntry.Max(x => x.id) + 1;

                string nome = string.Empty;
                if (jogo.lista_numeros != null)
                {
                    switch (jogo.lista_numeros.Count)
                    {
                        case 0:
                            break;
                        case 1:
                            nome = jogo.lista_numeros[0].ToString();
                            break;
                        default:
                            for (int i = 0; i < (jogo.lista_numeros.Count - 1); i++)
                            {
                                nome += jogo.lista_numeros[i].ToString() + " ";
                            }
                            nome += jogo.lista_numeros[jogo.lista_numeros.Count - 1].ToString();
                            break;
                    }
                }
                jogo.name = nome;
                jogo.dthr = DateTime.Now.ToString("dd/MM/yyyy HH:mm");
                cacheEntry.Add(jogo);
                
                // Save data in cache.
                _cache.Set(CacheKeys.Jogo, cacheEntry);

                return Ok(jogo);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        //
        //NADA PODE SER ALTERADO!
        //
        // PUT api/jogos/updateJogo
        //[HttpPut("{id}")] //original
        //[HttpPut(Name = "updateJogo")]
        //[Route("updateJogo")]
        //[ProducesResponseType(200)]
        //[ProducesResponseType(400)]
        //[ProducesResponseType(404)]
        //public IActionResult updateJogo([FromBody] Jogo jogo)
        //{
        //    try
        //    {
        //        List<Jogo> cacheEntry = _cache.GetOrCreate(CacheKeys.Jogo, entry => { return (List<Jogo>)(((OkObjectResult)getJogos()).Value); });

        //        int indice = cacheEntry.FindIndex(x => x.id.Equals(apostador.id));

        //                if (indice == -1)
        //                {
        //                    return NotFound();
        //    }

        //    //Apenas atributos que podem ser alterados
        //    //NADA PODE SER ALTERADO!

        //                return Ok(cacheEntry);
        //}
        //            catch (Exception)
        //            {
        //                return BadRequest();
        //            }
        //}

        // DELETE api/jogos/deleteJogo/5
        //[HttpDelete("{id}")]//Original
        [HttpDelete("{id}", Name = "deleteJogo")]
        [Route("deleteJogo/{id}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult deleteJogo(int id)
        {
            try
            {
                List<Jogo> cacheEntry = _cache.GetOrCreate(CacheKeys.Jogo, entry => { return (List<Jogo>)(((OkObjectResult)getJogos()).Value); });

                int quantidadeExcluidos = cacheEntry.RemoveAll(x => x.id.Equals(id));
                if (quantidadeExcluidos == 0)
                {
                    return NotFound();
                }

                // Save data in cache.
                _cache.Set(CacheKeys.Jogo, cacheEntry);

                return Ok(cacheEntry);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // api/jogos/getSurpresinha/1
        [HttpGet("{id}", Name = "getSurpresinha")]
        [Route("getSurpresinha/{id_Produto}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult getSurpresinha(int id_Produto)
        {
            try
            {
                List<int> retorno = null;

                var produtos = new ProdutosController(_cache).getProdutos();

                if (produtos == NotFound())
                {
                    return NotFound();
                }

                Produto produto = ((List<Produto>)((OkObjectResult)produtos).Value).Find(x => x.id.Equals(id_Produto));

                if (produto == null)
                {
                    return NotFound();
                }

                if (produto != null)
                {
                    retorno = new List<int>();
                    //TODO: se der tempo, aplicar HashSet
                    Random rnd = new Random();
                    //Foi convencionado que a primeira Regra associada ao Produto é sempre referente ao maior prêmio, ou seja, a principal.
                    //(ex. Sena - 6 números, da mega-sena)
                    //Além disso, que a SURPRESINHA contém a quantidade exata do maior prêmio.
                    for (int i = 0; i < (produto.lista_regras[0].qtd_vencer); i++)
                    {
                        //Retorna um número "aleatório" num intervalo de valores mínimo e máximo
                        int novo = rnd.Next(1, produto.qtd_max);

                        //Garantindo que não haja repetição entre os números de um mesmo jogo
                        while (retorno.Exists(x => x.Equals(novo)))
                        {
                            novo = rnd.Next(1, produto.qtd_max);
                        }

                        retorno.Add(novo);
                    }
                }

                return Ok(retorno);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // api/jogos/getResultado/1
        [HttpGet("{id}", Name = "getResultado")]
        [Route("getResultado/{id}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult getResultado(int id)
        {
            try
            {
                List<Jogo> retorno = new List<Jogo>();

                var prod = new ProdutosController(_cache).getProduto(id);

                if (prod == NotFound())
                {
                    return NotFound();
                }

                Produto produto = (Produto)((OkObjectResult)prod).Value;

                //O produto existe?
                if (produto != null && produto.id > 0)
                {
                    //Existem Regras associadas? (pelo menos uma)
                    if (produto.lista_regras != null && produto.lista_regras.Count > 0)
                    {
                        //Existe algum Jogo deste Produto?
                        List<Jogo> jogosDoProduto = ((List<Jogo>)((OkObjectResult)getJogos()).Value).FindAll(x => x.produto.id.Equals(id));

                        if (jogosDoProduto != null && jogosDoProduto.Count > 0)
                        {
                            //Realiza o SORTEIO
                            List<int> sorteio = (List<int>)(((OkObjectResult)getSurpresinha(id)).Value);
                            //Foi convencionado que a primeira Regra associada ao Produto é sempre referente ao maior prêmio, ou seja, a principal.
                            //(ex. Sena - 6 números, da mega-sena)
                            //Além disso, que a SURPRESINHA contém a quantidade exata do maior prêmio.
                            if (sorteio != null && sorteio.Count == produto.lista_regras[0].qtd_vencer)
                            {
                                Jogo sena = new Jogo();
                                sena.id = 0;
                                sena.produto = new Produto();
                                sena.produto = produto;
                                sena.apostador = new Apostador();
                                sena.apostador.name = "SORTEIO";
                                sena.lista_numeros = sorteio;
                                sena.dthr = DateTime.Now.ToString("dd/MM/yyyy HH:mm");

                                //Adiciona no retorno
                                retorno.Add(sena);

                                //Adiciona o jogo, efetivamente
                                var senaAdd = addJogo(sena);
                                if (senaAdd == BadRequest())
                                {
                                    return BadRequest();
                                }

                                //Faz a contagem de acertos de cada Jogo do Produto
                                foreach (var jogo in jogosDoProduto)
                                {
                                    int acertos = 0;
                                    foreach (var numero in sorteio)
                                    {
                                        if (jogo.lista_numeros.Exists(x => x.Equals(numero)))
                                        {
                                            acertos++;
                                        }
                                    }

                                    //Os VENCEDORES serão definidos a partir das Regras associadas ao Produto
                                    if (acertos > 0 && produto.lista_regras.Exists(x => x.qtd_vencer == acertos))
                                    {
                                        retorno[0].name = produto.lista_regras.Find(x => x.qtd_vencer == acertos).name;
                                        retorno.Add(jogo);
                                    }
                                }
                            }
                            else
                            {
                                return BadRequest();
                            }
                        }
                    }
                }

                if (retorno.Count == 1)
                {
                    retorno[0].name = "Não há vencedores";
                }

                return Ok(retorno);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // api/jogos/getConcurso/1
        [HttpGet("{id}", Name = "getConcurso")]
        [Route("getConcurso/{id}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult getConcurso(int id)
        {
            try
            {
                List<int> retorno = new List<int>();

                //Sempre tenho, pelo menos um, jogo retornando de 'getResultado(id)'
                var jogosSorteados = ((List<Jogo>)(((OkObjectResult)getJogos()).Value)).FindAll(x=>x.produto.id.Equals(id) && x.apostador.name.ToLower().Equals("sorteio"));

                if (jogosSorteados == null)
                {
                    return NotFound();
                }

                //Retorna o id do jogo mais recente
                int maiorID = jogosSorteados.Max(x => x.id);

                retorno = jogosSorteados.Find(x=>x.id.Equals(maiorID)).lista_numeros;

                if (retorno == null)
                {
                    return NotFound();
                }
         
                return Ok(retorno);
            }

            catch (Exception)
            {
                return BadRequest();
            }
        }


        // api/jogos/getSurpresinhas/1/3/
        [HttpGet("{id}", Name = "getSurpresinhas")]
        [Route("getSurpresinhas/{id}/{qtd_surpresinhas}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult getSurpresinhas(int id, int qtd_surpresinhas)
        {
            try
            {
                List<Jogo> retorno = new List<Jogo>();

                var prod = new ProdutosController(_cache).getProduto(id);

                if (prod == NotFound())
                {
                    return NotFound();
                }

                Produto produto = (Produto)((OkObjectResult)prod).Value;

                //O produto existe?
                if (produto != null && produto.id > 0)
                {
                    //Existem Regras associadas? (pelo menos uma)
                    if (produto.lista_regras != null && produto.lista_regras.Count > 0)
                    {
                        //Execute a quantidade de vezes indicada
                        for (int i = 0; i < qtd_surpresinhas; i++)
                        {
                            //Realiza o SORTEIO
                            List<int> sorteio = (List<int>)(((OkObjectResult)getSurpresinha(id)).Value);
                            //Foi convencionado que a primeira Regra associada ao Produto é sempre referente ao maior prêmio, ou seja, a principal.
                            //(ex. Sena - 6 números, da mega-sena)
                            //Além disso, que a SURPRESINHA contém a quantidade exata do maior prêmio.
                            if (sorteio != null && sorteio.Count == produto.lista_regras[0].qtd_vencer)
                            {
                                Jogo supresa = new Jogo();
                                supresa.id = 0;
                                supresa.produto = new Produto();
                                supresa.produto = produto;
                                supresa.apostador = new Apostador();
                                supresa.apostador.name = "SURPRESINHA";
                                supresa.lista_numeros = sorteio;
                                supresa.dthr = DateTime.Now.ToString("dd/MM/yyyy HH:mm");

                                //Adiciona no retorno
                                retorno.Add(supresa);

                                //Adiciona o jogo, efetivamente
                                var senaAdd = addJogo(supresa);
                                if (senaAdd == BadRequest())
                                {
                                    return BadRequest();
                                }
                            }
                            else
                            {
                                return BadRequest();
                            }
                        }
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                else
                {
                    return NotFound();
                }
                
                return Ok(retorno);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
}

