﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using LoteriasOnline.Controllers;
using LoteriasOnline.Models;
using Microsoft.Extensions.Caching.Memory;

namespace TesteUnitario
{
    [TestClass]
    public class JogoUT
    {
        private readonly JogosController _jogosController;

        private IMemoryCache _cache;

        public JogoUT()
        {
            _jogosController = new JogosController(_cache);
        }

        [TestMethod]
        public void RetornaFalsoSeNuloDeUm()
        {
            var resultado = _jogosController.getJogo(1);

            Assert.IsFalse((resultado == null), "Id:1 não deveria ser nulo.");
        }

        [TestMethod]
        public void RetornaFalsoSeNaoAdicionar()
        {
            Jogo jogo = new Jogo();
            jogo.name = "Teste";

            var resultado = _jogosController.addJogo(jogo);

            Assert.IsFalse((resultado == null), "Deveria ter adicionado.");
        }
        
        [TestMethod]
        public void RetornaFalsoSeNaoExcluir()
        {
            var resultado = _jogosController.deleteJogo(1);

            Assert.IsFalse((resultado == null), "Deveria ter excluído o Id:1.");
        }

        [TestMethod]
        public void RetornaFalsoSeNaoGerarSurpresinhas()
        {
            var resultado = _jogosController.getSurpresinhas(1, 2);

            Assert.IsFalse((resultado == null), "Deveria ter gerado a Surpresinha do Produto Id:1.");
        }

        [TestMethod]
        public void RetornaFalsoSeNaoExecutarResultado()
        {
            var resultado = _jogosController.getResultado(1);

            Assert.IsFalse((resultado == null), "Deveria ter executado o resultado do Produto Id:1.");
        }
    }
}

