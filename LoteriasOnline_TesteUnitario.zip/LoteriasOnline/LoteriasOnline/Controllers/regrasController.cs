﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

using LoteriasOnline.Models;
using System.Data.SqlClient;
using System.Collections;
using LoteriasOnline.Services;
using Microsoft.Extensions.Caching.Memory;

namespace LoteriasOnline.Controllers
{
    /*
     * BadRequestResult (400)
     * NotFoundResult (404)
     * OkObjectResult (200)
     */

    [Route("api/[controller]")]
    [Produces("application/json")]
    //[ApiController] //original
    public class RegrasController : Controller//ControllerBase
    {
        private RegraRepository regrasRepository;
        private IMemoryCache _cache;
        public RegrasController(IMemoryCache memoryCache)
        {
            _cache = memoryCache;
            this.regrasRepository = new RegraRepository();
        }

        public List<Regra> Get()
        {
            return this.regrasRepository.GetAllRegras();
        }

        // GET api/regras/getRegras
        //[HttpGet] //original
        [HttpGet(Name = "getRegras")]
        [Route("getRegras")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        public IActionResult getRegras()
        {
            try
            {
                List<Regra> cacheEntry = _cache.GetOrCreate(CacheKeys.Regra, entry => { return Get(); });

                //Execute
                cacheEntry = cacheEntry.OrderBy(x => x.id).ToList();
                
                return Ok(cacheEntry);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // GET api/regras/getRegra/5
        [HttpGet("{id}", Name = "getRegra")]
        [Route("getRegra/{id}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult getRegra(int id)
        {
            try
            {
                List<Regra> cacheEntry = _cache.GetOrCreate(CacheKeys.Regra, entry => { return (List<Regra>)(((OkObjectResult)getRegras()).Value); });

                Regra regra = cacheEntry.Find(x => x.id.Equals(id));

                if (regra == null)
                {
                    return NotFound();
                }

                return Ok(regra);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // POST api/regras/addRegra
        [HttpPost(Name = "addRegra")]
        [Route("addRegra")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        public IActionResult addRegra([FromBody] Regra regra)
        {
            try
            {
                List<Regra> cacheEntry = _cache.GetOrCreate(CacheKeys.Regra, entry => { return (List<Regra>)(((OkObjectResult)getRegras()).Value); });

                regra.id = cacheEntry.Max(x => x.id) + 1;

                cacheEntry.Add(regra);

                // Save data in cache.
                _cache.Set(CacheKeys.Regra, cacheEntry);

                return Ok(cacheEntry);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // PUT api/regras/updateRegra
        //[HttpPut("{id}")] //original
        [HttpPut(Name = "updateJogo")]
        [Route("updateJogo")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult updateRegra([FromBody] Regra regra)
        {
            try
            {
                List<Regra> cacheEntry = _cache.GetOrCreate(CacheKeys.Regra, entry => { return (List<Regra>)(((OkObjectResult)getRegras()).Value); });

                int indice = cacheEntry.FindIndex(x => x.id.Equals(regra.id));

                if (indice == -1)
                {
                    return NotFound();
                }

                //Apenas atributos que podem ser alterados
                cacheEntry[indice].name = regra.name;
                cacheEntry[indice].qtd_vencer = regra.qtd_vencer;

                // Save data in cache.
                _cache.Set(CacheKeys.Regra, cacheEntry);

                return Ok(cacheEntry);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // DELETE api/regras/deleteRegra/5
        //[HttpDelete("{id}")]
        [HttpDelete("{id}", Name = "deleteRegra")]
        [Route("deleteRegra/{id}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult deleteRegra(int id)
        {
            try
            {
                List<Regra> cacheEntry = _cache.GetOrCreate(CacheKeys.Regra, entry => { return (List<Regra>)(((OkObjectResult)getRegras()).Value); });

                int quantidadeExcluidos = cacheEntry.RemoveAll(x => x.id.Equals(id));
                if (quantidadeExcluidos == 0)
                {
                    return NotFound();
                }

                // Save data in cache.
                _cache.Set(CacheKeys.Regra, cacheEntry);

                return Ok(cacheEntry);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
}
