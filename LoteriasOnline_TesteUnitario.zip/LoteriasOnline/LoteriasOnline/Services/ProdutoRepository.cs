﻿using LoteriasOnline.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoteriasOnline.Services
{
    public class ProdutoRepository
    {
        public List<Produto> GetAllProdutos()
        {
            return new List<Produto>(new Produto[] {
                                                    new Produto{ id= 1, name= "mega-sena", qtd_max= 60, lista_regras= new RegraRepository().GetRegrasMegaSena() }
                                                    }
                                    );
        }
    }
}
