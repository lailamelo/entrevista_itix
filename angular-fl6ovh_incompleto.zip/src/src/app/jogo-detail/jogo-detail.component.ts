import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

import { Apostador } from '../apostador';
import { ApostadorService } from '../apostador.service';

import { Jogo } from '../jogo';
import { JogoService } from '../jogo.service';

import { Produto } from '../produto';
import { ProdutoService } from '../produto.service';

@Component({
  selector: 'app-jogo-detail',
  templateUrl: './jogo-detail.component.html',
  styleUrls: ['./jogo-detail.component.css']
})

export class JogoDetailComponent implements OnInit {
  @Input() jogo: Jogo;
  produto: Produto;

  constructor(
    private route: ActivatedRoute,
    private jogoService: JogoService,
    private produtoService: ProdutoService,
    private apostadorService: ApostadorService,
    private location: Location
  ) { }

  items: number[];
  createRange(number){
    this.items = [];
    for(var i = 1; i <= number; i++){
       this.items.push(i);
    }
    return this.items;
  }
  
  ngOnInit(): void {
    this.getJogo();
  }

  getJogo(): void {
    const id = +this.route.snapshot.paramMap.get('id');
    const id_Produto = +this.route.snapshot.paramMap.get('id_Produto');
    if (id !== 0) {
      this.jogoService.getJogo(id)
        .subscribe(jogo => this.jogo = jogo);
    }
    else {
      //alert(location.href);
      let obsproduto = this.produtoService.getProduto(id_Produto).subscribe(produto => this.produto = produto);
      this.jogo.produto = this.produto;
      Response.redirect(location.href);
    }
  }

  goBack(): void {
    this.location.back();
  }

  save(): void {
    this.jogoService.updateJogo(this.jogo)
      .subscribe(() => this.goBack());
  }

  //Apostador
  selectedApostador: Apostador;
  onSelect(apostador: Apostador): void {
    this.selectedApostador = apostador;
  }
}


/*
Copyright 2017-2018 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/