﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using LoteriasOnline.Controllers;
using LoteriasOnline.Models;
using Microsoft.Extensions.Caching.Memory;

namespace TesteUnitario
{
    [TestClass]
    public class ProdutoUT
    {
        private readonly ProdutosController _produtosController;

        private IMemoryCache _cache;

        public ProdutoUT()
        {
            _produtosController = new ProdutosController(_cache);
        }

        [TestMethod]
        public void RetornaFalsoSeNuloDeUm()
        {
            var resultado = _produtosController.getProduto(1);

            Assert.IsFalse((resultado == null), "Id:1 não deveria ser nulo.");
        }

        [TestMethod]
        public void RetornaFalsoSeNaoAdicionar()
        {
            Produto produto = new Produto();
            produto.name = "Teste";

            var resultado = _produtosController.addProduto(produto);

            Assert.IsFalse((resultado == null), "Deveria ter adicionado.");
        }

        [TestMethod]
        public void RetornaFalsoSeNaoAlterar()
        {
            Produto produto = new Produto();
            produto.id = 1;
            produto.name = "Teste alterado";

            var resultado = _produtosController.updateProduto(produto);

            Assert.IsFalse((resultado == null), "Deveria ter alterado o Id:1.");
        }

        [TestMethod]
        public void RetornaFalsoSeNaoExcluir()
        {
            var resultado = _produtosController.deleteProduto(1);

            Assert.IsFalse((resultado == null), "Deveria ter excluído o Id:1.");
        }
    }
}

