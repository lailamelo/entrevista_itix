﻿using LoteriasOnline.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoteriasOnline.Services
{
    public class JogoRepository
    {
        public List<Jogo> GetAllJogos()
        {
            return new List<Jogo>(new Jogo[] {
                                                new Jogo{ id= 100, apostador= new Apostador{ id= 100, name= "SORTEIO" }, produto= new ProdutoRepository().GetAllProdutos()[0], lista_numeros= new List<int>{2, 14 , 15, 25, 33, 54}, dthr= "11/09/2018 16:41", name= "2 14 15 25 33 54" },
                                                new Jogo{ id= 1, apostador= new ApostadorRepository().GetAllApostadores()[0], produto= new ProdutoRepository().GetAllProdutos()[0], lista_numeros= new List<int>{2, 14 , 15, 25, 33, 54}, dthr= "11/09/2018 14:41", name= "2 14 15 25 33 54" },
                                                new Jogo{ id= 2, apostador= new ApostadorRepository().GetAllApostadores()[1], produto= new ProdutoRepository().GetAllProdutos()[0], lista_numeros= new List<int>{3, 15, 17, 28, 38, 50}, dthr= "11/09/2018 15:30", name= "3 15 17 28 38 50" }
                                             }
                                 );
        }
    }
}
