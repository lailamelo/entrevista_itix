import { Component, OnInit } from '@angular/core';

import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

import { Produto } from '../produto';
import { ProdutoService } from '../produto.service';

@Component({
  selector: 'app-produtos',
  templateUrl: './produtos.component.html',
  styleUrls: ['./produtos.component.css']
})
export class ProdutosComponent implements OnInit {
  produto: Produto;
  produtos: Produto[];

  constructor(private produtoService: ProdutoService,
  private route: ActivatedRoute,
    private location: Location) { }

  ngOnInit() {
    this.getProdutos();
  }

  getProdutos(): void {
    this.produtoService.getProdutos()
    .subscribe(produtos => this.produtos = produtos);
  }

  // add(name: string): void {
    // name = name.trim();
    // if (!name) { return; }
    // this.produtoService.addProduto({ name } as Produto)
      // .subscribe(produto => {
        // this.produtos.push(produto);
      // });
  // }
  
    add(name: string): void {	
	name = name.trim();
    if (!name) { return; }
	
	if(this.produto == undefined) { 
		this.produto = new Produto();
	}
	
	this.produto.id = 0;
	this.produto.name = name;
	this.produto.qtd_max = 0;
	this.produtoService.addProduto(this.produto)
      .subscribe(() => this.goBack());
  }

  delete(produto: Produto): void {
    this.produtos = this.produtos.filter(h => h !== produto);
    this.produtoService.deleteProduto(produto).subscribe();
  }

	goBack(): void {
    this.location.back();
  }

  save(): void {
    this.produtoService.updateProduto(this.produto)
      .subscribe(() => this.goBack());
  }
  
};


/*
Copyright 2017-2018 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/