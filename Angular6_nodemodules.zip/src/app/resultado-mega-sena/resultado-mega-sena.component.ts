import { Component, OnInit } from '@angular/core';

import { Jogo } from '../jogo';
import { JogoService } from '../jogo.service';

@Component({
  selector: 'app-resultado-mega-sena',
  templateUrl: './resultado-mega-sena.component.html',
  styleUrls: ['./resultado-mega-sena.component.css']
})

export class ResultadoMegaSenaComponent implements OnInit {
  
  jogos: Jogo[] = [];
  concurso: number[] = [];

  constructor(private jogoService: JogoService) { }
  
  ngOnInit() {
	this.getResultado();
  }

  
  getResultado(): void {
    this.jogoService.getResultado(1)
      .subscribe(jogos => this.jogos = jogos);
  }
  
  getJogos(): void {
    this.jogoService.getJogos()
      .subscribe(jogos => this.jogos = jogos);
  }

  getConcurso(): void {
    this.concurso = this.jogos[0].lista_numeros;
  }
  
}