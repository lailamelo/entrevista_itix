export class Apostador {
  id: number;
  name: string;
}