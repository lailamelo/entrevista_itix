export class Regra {
  id: number;
  name: string;
  qtd_vencer: number;
}