﻿using LoteriasOnline.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoteriasOnline.Services
{
    public class RegraRepository
    {
        public List<Regra> GetAllRegras()
        {
            return new List<Regra>(new Regra[] {
                                                new Regra{ id= 1, name= "Sena", qtd_vencer= 6 },
                                                new Regra{ id= 2, name= "Quina", qtd_vencer= 5 },
                                                new Regra{ id= 3, name= "Quadra", qtd_vencer= 4 }
                                                }
            );
        }

        public List<Regra> GetRegrasMegaSena()
        {
            return new List<Regra>(new Regra[] {
                                                new Regra{ id= 1, name= "Sena", qtd_vencer= 6 },
                                                new Regra{ id= 2, name= "Quina", qtd_vencer= 5 },
                                                new Regra{ id= 3, name= "Quadra", qtd_vencer= 4 }
                                                }
            );
        }
    }
}
