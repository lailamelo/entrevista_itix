﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using LoteriasOnline.Controllers;
using LoteriasOnline.Models;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.AspNetCore.Mvc;

namespace TesteUnitario
{
    [TestClass]
    public class RegraUT
    {
        private readonly RegrasController _regrasController;

        private IMemoryCache _cache;
        private IActionResult _actionResult;

        public RegraUT()
        {
            _regrasController = new RegrasController(_cache);
        }

        [TestMethod]
        public void RetornaFalsoSeNuloDeUm()
        {
            var resultado = _regrasController.getRegra(1);

            Assert.IsFalse((resultado == null), "Id:1 não deveria ser nulo.");
        }

        [TestMethod]
        public void RetornaFalsoSeNaoAdicionar()
        {
            Regra regra = new Regra();
            regra.name = "Teste";

            var resultado = _regrasController.addRegra(regra);

            Assert.IsFalse((resultado == null), "Deveria ter adicionado.");
        }

        [TestMethod]
        public void RetornaFalsoSeNaoAlterar()
        {
            Regra regra = new Regra();
            regra.id = 1;
            regra.name = "Teste alterado";

            var resultado = _regrasController.updateRegra(regra);

            Assert.IsFalse((resultado == null), "Deveria ter alterado o Id:1.");
        }

        [TestMethod]
        public void RetornaFalsoSeNaoExcluir()
        {
            var resultado = _regrasController.deleteRegra(1);

            Assert.IsFalse((resultado == null), "Deveria ter excluído o Id:1.");
        }
    }
}

