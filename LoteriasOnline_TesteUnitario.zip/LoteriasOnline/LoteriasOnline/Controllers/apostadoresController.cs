﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

using LoteriasOnline.Models;
using System.Data.SqlClient;
using System.Collections;
using Microsoft.Extensions.Caching.Memory;
using LoteriasOnline.Services;

namespace LoteriasOnline.Controllers
{
    /*
     * BadRequestResult (400)
     * NotFoundResult (404)
     * OkObjectResult (200)
     */

    [Route("api/[controller]")]
    [Produces("application/json")]
    //[ApiController] //original
    public class ApostadoresController : Controller//ControllerBase
    {
        private ApostadorRepository apostadoresRepository;
        private IMemoryCache _cache;
        public ApostadoresController(IMemoryCache memoryCache)
        {
            _cache = memoryCache;
            this.apostadoresRepository = new ApostadorRepository();
        }

        public List<Apostador> Get()
        {
            return this.apostadoresRepository.GetAllApostadores();
        }

        // GET api/apostadores/getApostadores
        //[HttpGet] //original
        [HttpGet(Name = "getApostadores")]
        [Route("getApostadores")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult getApostadores()
        {
            try
            {
                List<Apostador> cacheEntry = _cache.GetOrCreate(CacheKeys.Apostador, entry => { return Get(); });

                //Execute
                cacheEntry = cacheEntry.OrderBy(x => x.name).ToList();

                // Save data in cache.
                _cache.Set(CacheKeys.Apostador, cacheEntry);
                
                return Ok(cacheEntry);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // GET api/apostadores/getApostador/5
        [HttpGet("{id}", Name = "getApostador")]
        [Route("getApostador/{id}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult getApostador(int id)
        {
            try
            {
                List<Apostador> cacheEntry = _cache.GetOrCreate(CacheKeys.Apostador, entry => { return (List<Apostador>)(((OkObjectResult)getApostadores()).Value); });

                Apostador apostador = cacheEntry.Find(x => x.id.Equals(id));

                if (apostador == null)
                {
                    return NotFound();
                }

                return Ok(apostador);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // POST api/apostadores/addApostador
        [HttpPost(Name = "addApostador")]
        [Route("addApostador")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        public IActionResult addApostador([FromBody] Apostador apostador)
        {
            try
            {
                List<Apostador> cacheEntry = _cache.GetOrCreate(CacheKeys.Apostador, entry => { return (List<Apostador>)(((OkObjectResult)getApostadores()).Value); });

                apostador.id = cacheEntry.Max(x => x.id) + 1;

                cacheEntry.Add(apostador);

                // Save data in cache.
                _cache.Set(CacheKeys.Jogo, cacheEntry);

                return Ok(cacheEntry);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // PUT api/apostadores/updateApostador
        //[HttpPut("{id}")] //original
        [HttpPut(Name = "updateApostador")]
        [Route("updateApostador")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult updateApostador([FromBody] Apostador apostador)
        {
            try
            {
                List<Apostador> cacheEntry = _cache.GetOrCreate(CacheKeys.Apostador, entry => { return (List<Apostador>)(((OkObjectResult)getApostadores()).Value); });

                int indice = cacheEntry.FindIndex(x => x.id.Equals(apostador.id));

                if (indice == -1)
                {
                    return NotFound();
                }

                //Apenas atributos que podem ser alterados
                cacheEntry[indice].name = apostador.name;

                // Save data in cache.
                _cache.Set(CacheKeys.Jogo, cacheEntry);

                return Ok(cacheEntry);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // DELETE api/apostadores/deleteApostador/5
        //[HttpDelete("{id}")]//Original
        [HttpDelete("{id}", Name = "deleteApostador")]
        [Route("deleteApostador/{id}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult deleteApostador(int id)
        {
            try
            {
                List<Apostador> cacheEntry = _cache.GetOrCreate(CacheKeys.Apostador, entry => { return (List<Apostador>)(((OkObjectResult)getApostadores()).Value); });

                int quantidadeExcluidos = cacheEntry.RemoveAll(x => x.id.Equals(id));
                if (quantidadeExcluidos == 0)
                {
                    return NotFound();
                }

                // Save data in cache.
                _cache.Set(CacheKeys.Jogo, cacheEntry);

                return Ok(cacheEntry);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
}
