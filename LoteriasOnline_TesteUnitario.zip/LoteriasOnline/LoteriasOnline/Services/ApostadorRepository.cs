﻿using LoteriasOnline.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoteriasOnline.Services
{
    public class ApostadorRepository
    {
        public List<Apostador> GetAllApostadores()
        {
            return new List<Apostador>(new Apostador[] {
                                                        new Apostador{ id= 1, name= "Daniel" },
                                                        new Apostador{ id= 2, name= "Marcos" },
                                                        new Apostador{ id= 3, name= "Marcela" },
                                                        new Apostador{ id= 4, name= "Joaquim" },
                                                        new Apostador{ id= 5, name= "Fernanda" }
                                                      }
                                        );
        }
    }
}
