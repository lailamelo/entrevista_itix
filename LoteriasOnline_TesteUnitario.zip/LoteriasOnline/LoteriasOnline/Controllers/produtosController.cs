﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

using LoteriasOnline.Models;
using System.Data.SqlClient;
using System.Collections;
using LoteriasOnline.Services;
using Microsoft.Extensions.Caching.Memory;

namespace LoteriasOnline.Controllers
{
    /*
     * BadRequestResult (400)
     * NotFoundResult (404)
     * OkObjectResult (200)
     */

    [Route("api/[controller]")]
    [Produces("application/json")]
    //[ApiController] //original
    public class ProdutosController : Controller//ControllerBase
    {
        private ProdutoRepository produtosRepository { get; set; }
        private IMemoryCache _cache;
        public ProdutosController(IMemoryCache memoryCache)
        {
            _cache = memoryCache;
            this.produtosRepository = new ProdutoRepository();
        }

        public List<Produto> Get()
        {
            return this.produtosRepository.GetAllProdutos();
        }

        // GET api/produtos/getProdutos
        //[HttpGet] //original
        [HttpGet(Name = "getProdutos")]
        [Route("getProdutos")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        public IActionResult getProdutos()
        {
            try
            {
                List<Produto> cacheEntry = _cache.GetOrCreate(CacheKeys.Produto, entry => { return Get(); });

                //Execute
                cacheEntry = cacheEntry.OrderBy(x => x.id).ToList();
                
                return Ok(cacheEntry);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // GET api/produtos/getProduto/5
        [HttpGet("{id}", Name = "getProduto")]
        [Route("getProduto/{id}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult getProduto(int id)
        {
            try
            {
                List<Produto> cacheEntry = _cache.GetOrCreate(CacheKeys.Produto, entry => { return (List<Produto>)(((OkObjectResult)getProdutos()).Value); });

                Produto produto = cacheEntry.Find(x => x.id.Equals(id));

                if (produto == null)
                {
                    return NotFound();
                }

                return Ok(produto);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // POST api/produtos/addProduto
        [HttpPost(Name = "addProduto")]
        [Route("addProduto")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        public IActionResult addProduto([FromBody] Produto produto)
        {
            try
            {
                List<Produto> cacheEntry = _cache.GetOrCreate(CacheKeys.Produto, entry => { return (List<Produto>)(((OkObjectResult)getProdutos()).Value); });

                produto.id = cacheEntry.Max(x => x.id) + 1;

                cacheEntry.Add(produto);

                // Save data in cache.
                _cache.Set(CacheKeys.Produto, cacheEntry);

                return Ok(cacheEntry);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // PUT api/produtos/updateProduto
        //[HttpPut("{id}")] //original
        [HttpPut(Name = "updateProduto")]
        [Route("updateProduto")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult updateProduto([FromBody] Produto produto)
        {
            try
            {
                List<Produto> cacheEntry = _cache.GetOrCreate(CacheKeys.Produto, entry => { return (List<Produto>)(((OkObjectResult)getProdutos()).Value); });

                int indice = cacheEntry.FindIndex(x => x.id.Equals(produto.id));

                if (indice == -1)
                {
                    return NotFound();
                }

                //Apenas atributos que podem ser alterados
                cacheEntry[indice].name = produto.name;
                cacheEntry[indice].qtd_max = produto.qtd_max;
                cacheEntry[indice].lista_regras = produto.lista_regras;


                // Save data in cache.
                _cache.Set(CacheKeys.Produto, cacheEntry);

                return Ok(cacheEntry);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // DELETE api/produtos/deleteProduto/5
        //[HttpDelete("{id}")]
        [HttpDelete("{id}", Name = "deleteProduto")]
        [Route("deleteProduto/{id}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult deleteProduto(int id)
        {
            try
            {
                List<Produto> cacheEntry = _cache.GetOrCreate(CacheKeys.Produto, entry => { return (List<Produto>)(((OkObjectResult)getProdutos()).Value); });

                int quantidadeExcluidos = cacheEntry.RemoveAll(x => x.id.Equals(id));
                if (quantidadeExcluidos == 0)
                {
                    return NotFound();
                }
                
                // Save data in cache.
                _cache.Set(CacheKeys.Produto, cacheEntry);

                return Ok(cacheEntry);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
    }
}
